import React, {Component} from 'react';
import {Line} from 'react-chartjs-2';
import {
  Grid,
  Dropdown,
  Segment,
  Checkbox,
  Divider,
  Table,
  Button,
  Icon
} from "semantic-ui-react";
import request from 'superagent';
import Header from './header.jsx';
import "../styles/style.css";

var weekName = [];
var newArr2 = [];
var tempArr = [];

export default class salesPerformance extends Component {
  constructor() {
    super();
    this.state = {
      categoryOptions: [],
      productOptions: [],
      promoOptions: [],
      channelPartners: [],
      channelSales: [],
      selectedCategory: '',
      selectedProduct: '',
      selectedPromo: '',
      SelectedChannel: '',
      partnerDetails: [],
      partnerSales: [],
      data: [],
      chartData: [],
      allSaleData: [],
      selectedSale: [],
      year: 2017,
      partnerall: [],
      totalSales: [],
      salesGraph: [],
      lineName: [
        "Tesco", "Amazon", "Sainsbury"
      ],
      weeks: [],
      wholeGraphData: [],
      multiCheck: [],
      checkData: [],
      isChecked: false,
      tableWeeks: [],
      mapMarkers:[],
      finalData:[]

    };
    this.handleCategoryChange = this.handleCategoryChange.bind(this);
    this.handleProductChange = this.handleProductChange.bind(this);
    this.handlePromoChange = this.handlePromoChange.bind(this);
    this.getCheckBoxStatus = this.getCheckBoxStatus.bind(this);
  }
  componentWillMount() {
    var context = this;
    var category = [];
    var categoryNew = [];
    var tempValue = [];
    request.post('http://localhost:1100/getCategory').end(function(err, res) {
      if (err || !res.ok) {
        alert('Oh no! error');
      } else {
        res.body.map((item, i) => {
          category.push(item);
        })
        category = category.filter(function(item, index, inputArray) {
          return inputArray.indexOf(item) == index;
        });
        category.map((item, i) => {
          categoryNew.push({key: item, value: item, text: item});
        })
        context.setState({categoryOptions: categoryNew});
      }
    });

    request.post('http://localhost:1100/getSalesDetails').end(function(err, res) {
      if (err || !res.ok) {
        alert('Oh no! error');
      } else {
        res.body.map((item) => {
          item.promoCode.map((item1) => {
            tempValue.push({partner: item1.partner, sale: item1.sale});
          })
        })

        context.setState({
          allSaleData: tempValue
        }, function() {});
      }
    });

    request.post('http://localhost:1100/getTotalSales').end(function(err, res) {
      if (err || !res.ok) {
        alert('Oh no! error');
      } else {
        var name = [];
        context.setState({tableWeeks: res.body});
        res.body.map((item, i) => {
          weekName.push(Object.keys(item.value));
          name.push({
            value: Object.values(item.value),
            Name: item.name
          });
        })
        // console.log(weekName);
        // console.log(name,"wewer");
        context.setState({
          checkData: name
        }, function() {
          // console.log(this.state.checkData,"checkData");
        });
      }
    })
  }

  handleCategoryChange(event, result) {
    var context = this;
    var products = [];
    var productNew = [];
    context.setState({selectedCategory: result.value});
    request.post('http://localhost:1100/getProduct').query({product: result.value}).end(function(err, res) {
      if (err || !res.ok) {
        alert('Oh no! error');
      } else {
        res.body[0].map((item) => {
          productNew.push({key: item, value: item, text: item});
        })
        context.setState({productOptions: productNew});
      }
    });
  }

  handleProductChange(event, result) {
    var context = this;
    var promocodes = [];
    var promocodesNew = [];
    context.setState({selectedProduct: result.value});
    request.post('http://localhost:1100/getPromocode').query({product: result.value}).end(function(err, res) {
      if (err || !res.ok) {
        alert('Oh no! error');
      } else {
        res.body.map((item, i) => {
          promocodes.push({key: item, value: item, text: item});
        })
        context.setState({promoOptions: promocodes});
      }
    });
  }

  handlePromoChange(event, result) {
    var context = this;
    var channelName = [];
    var channelValue = [];
    context.setState({selectedPromo: result.value});
    request.post('http://localhost:1100/getChannels').query({promo: result.value}).end(function(err, res) {
      if (err || !res.ok) {
        alert('Oh no! error');
      } else {
        context.setState({partnerDetails: res.body});
        res.body.map((item, i) => {
          channelValue = Object.values(item);
          channelName = Object.keys(item);
        })
        context.setState({
          channelPartners: channelName
        }, function() {
          var temp1 = [];
          context.state.allSaleData.map((item) => {
            temp1.push({partner: item.partner, sale: item.sale});
          })
          context.setState({
            partnerall: temp1
          }, function() {
            request.post('http://localhost:1100/getTotalSales').end(function(err, res) {
              if (err || !res.ok) {
                alert('Oh no! error');
              } else {
                var name = [];
                res.body.map((item, i) => {
                  weekName.push(Object.keys(item.value));
                  name.push({
                    value: Object.values(item.value),
                    Name: item.name
                  });
                })
               context.setState({wholeGraphData: name});
              context.setState({partnerSales: name});
                var newArr1 = [];
                name.map((item) => {
                  newArr1 = newArr1.concat(item.value);
                })
                 console.log("newArr1 ",newArr1);
                weekName.map((item) => {
                  newArr2 = newArr2.concat(item);
                })
                // console.log("newArr2 ",newArr2);
                newArr2 = newArr2.filter(function(item, index, inputArray) {
                  return inputArray.indexOf(item) == index;
                })
                context.setState({weeks: newArr2});
                // context.setState({partnerSales:newArr1},function(){
                //   console.log(context.state.partnerSales," < -- partnerSales state");
                // });
              }
            })
          });
        });
        context.setState({channelSale: channelValue});
      }

    });

    request.post('http://localhost:1100/getPromoSales').query({promoSales: result.value}).end(function(err, res) {
      if (err || !res.ok) {
        alert('Oh no! error');
      } else {
        var amt = "€" + res.text.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
        context.setState({totalSales: amt});
      }
    });
  }

  getCheckBoxStatus(e, data) {
    var temp = this.state.partnerSales;
    var context = this;
    var selectSale = {};
    var array = [];
    var checkArray1 = [];
    var checkArray = this.state.partnerSales;
    if (data.checked == true) {
      var temp1 = this.state.partnerall;
      context.state.allSaleData.map((item5) => {
        if (item5.partner == data.name) {
          temp1.push({partner: data.name, sale: item5.sale})
        }
      })
      context.setState({partnerall: temp1});

      var check = this.state.checkData;
      console.log("check ", check);
      check.map((item) => {
        if (data.name == item.Name) {
          checkArray.push({name: item.Name, value: item.value});
        }
      })
      context.setState({partnerSales: checkArray});

      const dump = [];
      this.state.partnerSales.map((item, i) => {
        dump.push(item.value);
      })
      var value = [];
      dump.map((item) => {
        value = value.concat(item);
      })
      var currencyValue = [];
      if (value != 0) {
        value.map((item, i) => {
          var x = parseFloat(item.replace(/[^\d\.]/g, ''));
          currencyValue.push(x);

        })
      }
      var markers = [];
      var temparray = [];
      if (currencyValue.length > 0) {
        var split = 12;
        for (var i = 0; i < currencyValue.length; i += 12) {
          temparray = currencyValue.slice(i, i + split);
          markers.push(temparray);
        }
      }
      console.log("markers", markers);
      context.setState({mapMarkers:markers},function(){
        var graphData = {
          labels: newArr2,
          datasets: []
        };
        this.state.mapMarkers.map((item) => {

          graphData.datasets.push({
            label: 'Product Performance',
            fill: false,
            lineTension: 0.1,
            backgroundColor: 'rgba(75,192,192,0.4)',
            borderColor: 'rgba(75,192,192,1)',
            borderCapStyle: 'butt',
            borderDash: [],
            borderDashOffset: 0.0,
            borderJoinStyle: 'miter',
            pointBorderColor: 'rgba(75,192,192,1)',
            pointBackgroundColor: '#fff',
            pointBorderWidth: 1,
            pointHoverRadius: 5,
            pointHoverBackgroundColor: 'rgba(75,192,192,1)',
            pointHoverBorderColor: 'rgba(220,220,220,1)',
            pointHoverBorderWidth: 2,
            pointRadius: 1,
            pointHitRadius: 10,
            data: item
          })
          context.setState({finalData:graphData},function(){
            console.log(this.state.finalData,"data");
          });

        })
      });

    } else {
      console.log("data", data);
      var temp = this.state.partnerSales;

      // var unCheck=this.state.wholeGraphData;
      //
      // unCheck.map((item)=>{
      //   if(item.Name == data.name){
      //     unCheck.splice(unCheck.indexOf(item),1)
      //   }
      // })
      //   console.log("unCheck==>" ,unCheck);
      // var unCheckArr1=[];
      // unCheck.map((item)=>{
      //   unCheckArr1 = unCheckArr1.concat(item.value);
      // })
      // context.setState({partnerSales:unCheckArr1},function(){
      //   console.log("partnerSales==>" ,this.state.partnerSales);
      // });
      var temp4 = context.state.partnerall;
      temp4.map((item) => {
        if (item.partner == data.name) {
          temp4.splice(temp4.indexOf(item), 1)
        }
      })
      this.setState({partnerall: temp4});
    }
  }

  render() {
    console.log("partner sales in render -- > ", this.state.partnerSales);
    console.log("graphData ",this.state.finalData);
    // console.log("wholeData in render -- > ",this.state.wholeGraphData);

    let inputs = (this.state.channelPartners.map((item, index) => {
      return (<div>
        <Checkbox label={item} name={item} key={index} onChange={this.getCheckBoxStatus} defaultChecked="defaultChecked"/>
      </div>)
    }))

    // const dump = [];
    // this.state.partnerSales.map((item, i) => {
    //   console.log(item.value, "!!!!!!!!!!");
    //   dump.push(item.value);
    // })
    // console.log("@@@@", dump);
    // var value = [];
    // dump.map((item) => {
    //   value = value.concat(item);
    // })
    // console.log("$$$", value);
    // var currencyValue = [];
    // if (value != 0) {
    //   value.map((item, i) => {
    //     var x = parseFloat(item.replace(/[^\d\.]/g, ''));
    //     currencyValue.push(x);
    //
    //   })
    // }
    // console.log("currencyValue", currencyValue);
    // var markers = [];
    // var temparray = [];
    // if (currencyValue.length > 0) {
    //   var split = 12;
    //   for (var i = 0; i < currencyValue.length; i += 12) {
    //     temparray = currencyValue.slice(i, i + split);
    //     markers.push(temparray);
    //   }
    // }
    // console.log("markers", markers);

    // var data = {
    //   labels: newArr2,
    //   datasets: []
    // };
    //
    // console.log(this.state.mapMarkers,"mapMarkers");
    // this.state.mapMarkers.map((item) => {
    //   data.datasets.push({
    //     label: 'Product Performance',
    //     fill: false,
    //     lineTension: 0.1,
    //     backgroundColor: 'rgba(75,192,192,0.4)',
    //     borderColor: 'rgba(75,192,192,1)',
    //     borderCapStyle: 'butt',
    //     borderDash: [],
    //     borderDashOffset: 0.0,
    //     borderJoinStyle: 'miter',
    //     pointBorderColor: 'rgba(75,192,192,1)',
    //     pointBackgroundColor: '#fff',
    //     pointBorderWidth: 1,
    //     pointHoverRadius: 5,
    //     pointHoverBackgroundColor: 'rgba(75,192,192,1)',
    //     pointHoverBorderColor: 'rgba(220,220,220,1)',
    //     pointHoverBorderWidth: 2,
    //     pointRadius: 1,
    //     pointHitRadius: 10,
    //     data: item
    //   })
    //
    // })




    return (<div >
      <h2>Product Performance on Promocode</h2>
      <Grid >
        <Grid.Column width={2}>
          <h3>Year</h3>
          <Button icon="icon" labelPosition='right'>
            <Icon name='calendar outline'/>
            2017
          </Button>
        </Grid.Column>
        <Grid.Column width={3}>
          <h3>Category</h3>
          <Dropdown className='dropdown' placeholder='Select Category' fluid="fluid" selection="selection" options={this.state.categoryOptions} onChange={this.handleCategoryChange}/>
        </Grid.Column>

        <Grid.Column width={3}>
          <h3>Product</h3>
          <Dropdown placeholder='Select Product' fluid="fluid" selection="selection" options={this.state.productOptions} onChange={this.handleProductChange}/>
        </Grid.Column>

        <Grid.Column width={3}>
          <h3>Promocode</h3>
          <Dropdown placeholder='Select Promocode' fluid="fluid" selection="selection" options={this.state.promoOptions} onChange={this.handlePromoChange}/>
        </Grid.Column>

        <Grid.Column width={4}>
          <h3>Channel Partners</h3>
          <Segment>
            {inputs}
          </Segment>
        </Grid.Column>

      </Grid>
      <Divider horizontal="horizontal"></Divider>
      <Grid>
        <Grid.Column width={16}>
          <div className="table">
            <Table celled="celled" structured="structured">
              <Table.Header >
                <Table.Row >
                  <Table.HeaderCell style={{
                      "backgroundColor" : "#d1cfcf"
                    }}>Year</Table.HeaderCell>
                  <Table.HeaderCell style={{
                      "backgroundColor" : "#d1cfcf"
                    }}>Category</Table.HeaderCell>
                  <Table.HeaderCell style={{
                      "backgroundColor" : "#d1cfcf"
                    }}>Product</Table.HeaderCell>
                  <Table.HeaderCell style={{
                      "backgroundColor" : "#d1cfcf"
                    }}>Promocode</Table.HeaderCell>
                  <Table.HeaderCell style={{
                      "backgroundColor" : "#d1cfcf"
                    }}>Total Sales</Table.HeaderCell>
                  <Table.HeaderCell style={{
                      "backgroundColor" : "#d1cfcf"
                    }}>Weeks</Table.HeaderCell>
                  <Table.HeaderCell style={{
                      "backgroundColor" : "#d1cfcf"
                    }}>Partners</Table.HeaderCell>
                </Table.Row>
              </Table.Header>
              <Table.Body>
                <Table.Row>
                  <Table.Cell>
                    {this.state.year}
                  </Table.Cell>
                  <Table.Cell>
                    {this.state.selectedCategory}
                  </Table.Cell>
                  <Table.Cell>
                    {this.state.selectedProduct}
                  </Table.Cell>
                  <Table.Cell>
                    {this.state.selectedPromo}
                  </Table.Cell>
                  <Table.Cell>
                    {this.state.totalSales}
                  </Table.Cell>
                  <Table.Cell>
                    <Table.Cell>
                      <Table.Row>
                        {
                          this.state.weeks.map((item) => {
                            return (<Table.Row >
                              {item}
                            </Table.Row>)
                          })
                        }
                      </Table.Row>
                    </Table.Cell>

                    {/* <Table.Cell>
                  {this.state.partnerSales.map((item)=>{
                      if(this.state.partnerSales.length>0){
                        var splitTable=12;
                        for(var i=0;i<this.state.partnerSales.length;i+=12){
                          splitArray=this.state.partnerSales.slice(i,i+split);
                          markers.push(splitArray);
                        }
                    }
                      console.log(item,"gf");
                  })
                }
                </Table.Cell> */
                    }
                  </Table.Cell>
                  <Table.Cell>
                    {
                      this.state.partnerall.map((item) => {
                        return (<span>{item.partner}
                          - {item.sale}<br/></span>)
                      })
                    }
                  </Table.Cell>
                </Table.Row>
              </Table.Body>
            </Table>

          </div>
        </Grid.Column>
      </Grid>

      <Divider horizontal="horizontal"></Divider>
      {
        this.state.partnerSales.length != 0
          ? <Grid>
              <Grid.Column width={16}>
                <div className="chart">
                  <Line data={this.state.finalData}/>
                </div>
              </Grid.Column>
            </Grid>
          : null
      }
    </div>);
  }
}
