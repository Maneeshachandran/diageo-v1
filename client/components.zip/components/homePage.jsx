import React, {Component} from 'react';
import {Checkbox, Grid, Form, Table} from 'semantic-ui-react';
import request from 'superagent';
import "../styles/style.css";
export default class HomePage extends Component {
  constructor() {
    super();
    this.state = {
      value: '',
      value1: '',
      productvalue:'',
      productvalue1:'',
      promovalue:'',
      promovalue1:'',
      categoryOptions: [],
      productOptions: [],
      promoOptions:[],
      channelPartners:[],
      allSaleData:[],
      tableWeeks:[],
      checkData:[],
      weeks:[],
      partnerall:[],
      totalSales:[]
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleCategoryChange = this.handleCategoryChange.bind(this);
    this.handleProductChange = this.handleProductChange.bind(this);
    this.productChange = this.productChange.bind(this);
    this.handlePromoChange = this.handlePromoChange.bind(this);
    this.promocodeChange = this.promocodeChange.bind(this);
  }
  handleChange(e, value) {
    console.log('value', value.label);
    this.setState({value: value.value, value1: value.label})
    this.handleCategoryChange(value.label);
  }
  productChange(e,value){
    console.log('value',value);
    this.setState({productvalue: value.value, productvalue1: value.label})
    this.handleProductChange(value.label);
  }
  promocodeChange(e,value){
    var context=this;
    console.log('promo',value.label);
    context.setState({promovalue: value.value, promovalue1: value.label})
    context.handlePromoChange(value.label)
  }
  componentWillMount() {
    var context = this;
    var category = [];
    var categoryNew = [];
    var tempValue = [];
    var weekName = [];
    request.post('http://localhost:1100/getCategory').end(function(err, res) {
      if (err || !res.ok) {
        alert('Oh no! error');
      } else {
        res.body.map((item, i) => {
          category.push(item);
        })
        category = category.filter(function(item, index, inputArray) {
          return inputArray.indexOf(item) == index;
        });
        category.map((item, i) => {
          categoryNew.push({key: item, value: item, text: item});
        })
        context.setState({categoryOptions: categoryNew});
      }
    });
    request.post('http://localhost:1100/getSalesDetails')
       .end(function(err, res){
         if (err || !res.ok) {
               alert('Oh no! error');
             } else {
              res.body.map((item)=>{
                item.promoCode.map((item1)=>{
                  tempValue.push({partner:item1.partner,sale:item1.sale});
                })
               })

               context.setState({allSaleData:tempValue},function(){
              });
             }
            });

            request.post('http://localhost:1100/getTotalSales')
            .end(function(err, res){
              if (err || !res.ok) {
                    alert('Oh no! error');
                  } else {
                    var name=[];
                    context.setState({tableWeeks:res.body});
                    res.body.map((item,i)=>{
                      weekName.push(Object.keys(item.value));
                      name.push({value:Object.values(item.value),Name:item.name});
                    })
                    // console.log(weekName);
                  // console.log(name,"wewer");
                  context.setState({checkData:name},function(){
                    // console.log(this.state.checkData,"checkData");
                  });
}
})
  }
  handleCategoryChange(result) {
    console.log('inside function',result);
    var context = this;
    var products = [];
    var productNew = [];
    context.setState({selectedCategory: result});
    request.post('http://localhost:1100/getProduct').query({product: result}).end(function(err, res) {
      if (err || !res.ok) {
        alert('Oh no! error');
      } else {
        res.body[0].map((item) => {
          productNew.push({key: item, value: item, text: item});
        })
        context.setState({productOptions: productNew});
      }
    });
  }
  handleProductChange(result){
   var context=this;
   var promocodes=[];
   var promocodesNew=[];
   context.setState({selectedProduct:result});
   request.post('http://localhost:1100/getPromocode')
   .query({product:result})
   .end(function(err, res){
     if (err || !res.ok) {
           alert('Oh no! error');
         } else {
           res.body.map((item,i)=>{
             promocodes.push({key:item,value:item,text:item});
           })
           context.setState({promoOptions:promocodes});
         }
        });
 }
 handlePromoChange(result){
    var context=this;
    var channelName=[];
    var channelValue=[];
    var weekName=[];
    var newArr2=[];
    context.setState({selectedPromo:result});
    request.post('http://localhost:1100/getChannels')
    .query({promo:result})
    .end(function(err, res){
      if (err || !res.ok) {
            alert('Oh no! error');
          } else {
              context.setState({partnerDetails:res.body});
              res.body.map((item,i)=>{
            channelValue = Object.values(item);
            channelName =  Object.keys(item);
              })
          context.setState({channelPartners:channelName},function(){
            var temp1=[];
            context.state.allSaleData.map((item)=>{
               temp1.push({partner:item.partner,sale:item.sale});
            })
            context.setState({partnerall:temp1},function(){
              // console.log(context.state.partnerall,"all");
              request.post('http://localhost:1100/getTotalSales')
              .end(function(err, res){
                if (err || !res.ok) {
                      alert('Oh no! error');
                    } else {
                      var name=[];
                      res.body.map((item,i)=>{
                        weekName.push(Object.keys(item.value));
                        name.push({value:Object.values(item.value),Name:item.name});
                      })
                      // console.log(weekName);
                    // console.log(name,"wewer");
                    context.setState({wholeGraphData:name});
                      var newArr1=[];
                      name.map((item)=>{
                        newArr1 = newArr1.concat(item.value);
                      })
                      // console.log("newArr1 ",newArr1);
                      weekName.map((item)=>{
                        newArr2 = newArr2.concat(item);
                      })
                      // console.log("newArr2 ",newArr2);
                      newArr2 = newArr2.filter( function( item, index, inputArray ) {
                					return inputArray.indexOf(item) == index;
                        })
                      context.setState({weeks:newArr2});
                      // context.setState({partnerSales:newArr1},function(){
                      // //  console.log(context.state.partnerSales," < -- partnerSales state");
                      // });
                    }
              })
            });
          });
          context.setState({channelSale:channelValue});
          }

         });

         request.post('http://localhost:1100/getPromoSales')
         .query({promoSales:result})
         .end(function(err, res){
            if (err || !res.ok) {
                  alert('Oh no! error');
                } else {
                  var amt="€"+res.text.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
                 context.setState({totalSales:amt},function(){
               console.log('log',this.state.totalSales)});
                }
               });
 }
  render() {
    var category = (this.state.categoryOptions.map((item) => {
      return (<div>
        <Checkbox label={item.key} name='checkboxRadioGroup1' value={item.key} checked={this.state.value == item.key} onChange={this.handleChange}/></div>)
    }))
    var product = (this.state.productOptions.map((item1) => {
      return (<div>
        <Checkbox label={item1.key} name='checkboxRadioGroup2' value={item1.key} checked={this.state.productvalue == item1.key} onChange={this.productChange}/></div>)
    }))
    var promocode = (this.state.promoOptions.map((item2) => {
      return (<div>
        <Checkbox label={item2.key} name='checkboxRadioGroup3' value={item2.key} checked={this.state.promovalue == item2.key} onChange={this.promocodeChange}/></div>)
    }))
    var inputs =  (this.state.channelPartners.map((item, index)=> {
        return (
          <div>
                  <Checkbox label={item} name={item}
                    key={index} onChange={this.getCheckBoxStatus} defaultChecked/>
          </div>
        )
      })
      )
    return (<div>
      <Grid>
        <Grid.Row>
          <Grid.Column width={1}/>
          <Grid.Column width={4}>
            <Form>
              <Form.Field></Form.Field>
              <Form.Field>
                Category : {category}
              </Form.Field>
              {this.state.value1 == 0 ? null : <Form.Field>
                Product : {product}
              </Form.Field>}
              {this.state.productvalue1 == 0 ? null : <Form.Field>
                Promocode : {promocode}
              </Form.Field>}
              {this.state.promovalue1 == 0 ? null : <Form.Field>
                Channel Partner : {inputs}
              </Form.Field>
              }
            </Form>
          </Grid.Column>
          <Grid.Column width={10}>
            <Table celled structured>
              <Table.Header >
                <Table.Row >
                  <Table.HeaderCell style={{"backgroundColor":"#d1cfcf"}}>Category</Table.HeaderCell>
                  <Table.HeaderCell style={{"backgroundColor":"#d1cfcf"}}>Product</Table.HeaderCell>
                  <Table.HeaderCell style={{"backgroundColor":"#d1cfcf"}}>Promocode</Table.HeaderCell>
                  <Table.HeaderCell style={{"backgroundColor":"#d1cfcf"}}>Total Sales</Table.HeaderCell>
                  <Table.HeaderCell style={{"backgroundColor":"#d1cfcf"}}>Partners</Table.HeaderCell>
                </Table.Row>
              </Table.Header>
              <Table.Body>
                <Table.Row>
                  <Table.Cell>
                  	{this.state.value1}
                  </Table.Cell>
                   <Table.Cell>
                    {this.state.productvalue1}
                  </Table.Cell>
                   <Table.Cell>
                    {this.state.promovalue1}
                  </Table.Cell>
                   <Table.Cell>
                     {this.state.totalSales}
                  </Table.Cell>
                  <Table.Cell>
                    {this.state.partnerall.map((item)=>{
                      return(<span>{item.partner} - {item.sale}<br/></span>)
                    })}
                 </Table.Cell>
                  </Table.Row>
              </Table.Body>
            </Table>
          </Grid.Column>
          <Grid.Column width={1}/>
        </Grid.Row>
      </Grid>
    </div>)
  }

}
